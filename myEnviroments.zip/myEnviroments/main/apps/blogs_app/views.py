from django.shortcuts import render, HttpResponse, redirect
  # the index function is called when root is visited

 def index('/'):
    response = "placeholder to later display all the list of blogs"
    return HttpResponse(response)

 def index('/new'):
    response = "placeholder to display a new form to create a new blog"
    return HttpResponse(response)

def index('/create', method:'create'):
   
    return redirect ('index.html')

def index('/{{number}}', method:'show'):
    response = 'placeholder to display blog {{number}}'
    return HttpResponse(response)

def index('/{{number}}/edit', method:'edit'):
    response = 'placeholder to edit blog {{number}}
    return HttpResponse(response)

def index('/{{number}}/delete', method:'destroy'):
    return redirect('')
